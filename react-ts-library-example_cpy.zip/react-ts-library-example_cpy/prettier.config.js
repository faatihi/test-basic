module.exports = {
	parser: "typescript",
};
